// const key_vworld = "83F70F59-D916-3DBE-BD0C-F43C89012750";
// const key_sgis_service_id = "7b8b0bb22aff40839632"; // 서비스 id
// const key_sgis_security = "d8abd928823f43ddb25c"; // 보안 key
// const key_data = "oJ9KIluv1bgnj0XV+2ZGFMz1oxCr8wejIJezVmot3r41VDXCkeJL03vbZr/7S6W55BY40WzkKoPVaRyn5/jx0g==";
// const key_data = "2MyVMUNZ8YSPwbMXOcVkb1xdy5qgnwokKA4CcpQaZ98nJHbOZBmTgzZ0VhLyzlOsRdhiiBVvoqgX1Kj/tjZu5A==";
// data.go.kr 인증키

// END
