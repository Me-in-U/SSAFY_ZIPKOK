// package com.ssafy.house.model.dto;

// import lombok.Data;

// @Data
// public class ChatMessage {
// private String role; // "user" 또는 "system"
// private String content;
// }
