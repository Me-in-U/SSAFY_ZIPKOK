package com.ssafy.house.ai.advisor;

import java.util.Map;

import org.springframework.ai.chat.client.advisor.api.AdvisedRequest;
import org.springframework.ai.chat.client.advisor.api.AdvisedResponse;
import org.springframework.ai.chat.client.advisor.api.CallAroundAdvisor;
import org.springframework.ai.chat.client.advisor.api.CallAroundAdvisorChain;

// TODO: 06-2. CallAroundAdvisor를 구현한 ReReadingAdvisor를 생성해보자.
//  https://docs.spring.io/spring-ai/reference/1.0/api/advisors.html#_re_reading_re2_advisor
public class ReReadingAdvisor {
}

// END
