package com.ssafy.house;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YoucanbuyuhouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
